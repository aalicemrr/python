# app.py
# Painel de Tarefas - Sistema web feito com Flask e SQLite
# Projeto escolar - Ensino Técnico em Informática

import sqlite3
import os
from functools import wraps
from flask import Flask, render_template, request, redirect, url_for, session, flash, jsonify
from werkzeug.security import generate_password_hash, check_password_hash

app = Flask(__name__)

# Chave secreta usada pelo Flask para proteger a sessão do usuário
# Em ambiente de produção, o ideal é pegar essa chave de uma variável de ambiente
app.secret_key = os.environ.get("SECRET_KEY", "chave-secreta-do-projeto-escolar")

NOME_BANCO = "tarefas.db"


# ---------------------------------------------------------
# FUNÇÕES DE BANCO DE DADOS
# ---------------------------------------------------------

def conectar_banco():
    """Cria e retorna uma conexão com o banco SQLite."""
    conexao = sqlite3.connect(NOME_BANCO)
    conexao.row_factory = sqlite3.Row  # permite acessar as colunas pelo nome
    return conexao


def criar_banco():
    """Cria as tabelas do banco de dados caso ainda não existam."""
    conexao = conectar_banco()
    cursor = conexao.cursor()

    cursor.execute("""
        CREATE TABLE IF NOT EXISTS usuarios (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            nome TEXT NOT NULL,
            email TEXT NOT NULL UNIQUE,
            senha TEXT NOT NULL
        )
    """)

    cursor.execute("""
        CREATE TABLE IF NOT EXISTS tarefas (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            usuario_id INTEGER NOT NULL,
            titulo TEXT NOT NULL,
            descricao TEXT,
            status TEXT NOT NULL DEFAULT 'pendente',
            data_criacao TEXT DEFAULT CURRENT_TIMESTAMP,
            FOREIGN KEY (usuario_id) REFERENCES usuarios (id)
        )
    """)

    conexao.commit()
    conexao.close()


# ---------------------------------------------------------
# DECORADOR DE PROTEÇÃO DE ROTAS
# ---------------------------------------------------------

def login_obrigatorio(funcao):
    """Impede o acesso a rotas protegidas caso o usuário não esteja logado."""
    @wraps(funcao)
    def rota_protegida(*args, **kwargs):
        if "usuario_id" not in session:
            flash("Você precisa fazer login para acessar essa página.", "aviso")
            return redirect(url_for("login"))
        return funcao(*args, **kwargs)
    return rota_protegida


# ---------------------------------------------------------
# ROTA INICIAL
# ---------------------------------------------------------

@app.route("/")
def index():
    """Redireciona para o painel se estiver logado, senão para o login."""
    if "usuario_id" in session:
        return redirect(url_for("dashboard"))
    return redirect(url_for("login"))


# ---------------------------------------------------------
# CADASTRO DE USUÁRIO
# ---------------------------------------------------------

@app.route("/cadastro", methods=["GET", "POST"])
def cadastro():
    if request.method == "POST":
        nome = request.form.get("nome", "").strip()
        email = request.form.get("email", "").strip().lower()
        senha = request.form.get("senha", "")
        confirmar_senha = request.form.get("confirmar_senha", "")

        # Validações básicas do formulário
        if not nome or not email or not senha or not confirmar_senha:
            flash("Preencha todos os campos.", "erro")
            return redirect(url_for("cadastro"))

        if "@" not in email or "." not in email:
            flash("Digite um e-mail válido.", "erro")
            return redirect(url_for("cadastro"))

        if len(senha) < 4:
            flash("A senha deve ter pelo menos 4 caracteres.", "erro")
            return redirect(url_for("cadastro"))

        if senha != confirmar_senha:
            flash("As senhas não coincidem.", "erro")
            return redirect(url_for("cadastro"))

        senha_criptografada = generate_password_hash(senha)

        conexao = conectar_banco()
        cursor = conexao.cursor()

        # Verifica se o e-mail já está cadastrado
        cursor.execute("SELECT id FROM usuarios WHERE email = ?", (email,))
        usuario_existente = cursor.fetchone()

        if usuario_existente:
            flash("Esse e-mail já está cadastrado.", "erro")
            conexao.close()
            return redirect(url_for("cadastro"))

        cursor.execute(
            "INSERT INTO usuarios (nome, email, senha) VALUES (?, ?, ?)",
            (nome, email, senha_criptografada)
        )
        conexao.commit()
        conexao.close()

        flash("Cadastro realizado com sucesso! Faça login.", "sucesso")
        return redirect(url_for("login"))

    return render_template("cadastro.html")


# ---------------------------------------------------------
# LOGIN E LOGOUT
# ---------------------------------------------------------

@app.route("/login", methods=["GET", "POST"])
def login():
    if request.method == "POST":
        email = request.form.get("email", "").strip().lower()
        senha = request.form.get("senha", "")

        if not email or not senha:
            flash("Preencha e-mail e senha.", "erro")
            return redirect(url_for("login"))

        conexao = conectar_banco()
        cursor = conexao.cursor()
        cursor.execute("SELECT * FROM usuarios WHERE email = ?", (email,))
        usuario = cursor.fetchone()
        conexao.close()

        if usuario and check_password_hash(usuario["senha"], senha):
            session["usuario_id"] = usuario["id"]
            session["usuario_nome"] = usuario["nome"]
            flash(f"Bem-vindo(a), {usuario['nome']}!", "sucesso")
            return redirect(url_for("dashboard"))
        else:
            flash("E-mail ou senha incorretos.", "erro")
            return redirect(url_for("login"))

    return render_template("login.html")


@app.route("/logout")
def logout():
    session.clear()
    flash("Você saiu da sua conta.", "sucesso")
    return redirect(url_for("login"))


# ---------------------------------------------------------
# PAINEL PRINCIPAL (DASHBOARD)
# ---------------------------------------------------------

@app.route("/dashboard")
@login_obrigatorio
def dashboard():
    return render_template("painel.html", nome_usuario=session["usuario_nome"])


# ---------------------------------------------------------
# CRIAR NOVA TAREFA
# ---------------------------------------------------------

@app.route("/nova_tarefa", methods=["POST"])
@login_obrigatorio
def nova_tarefa():
    titulo = request.form.get("titulo", "").strip()
    descricao = request.form.get("descricao", "").strip()

    if not titulo:
        flash("O título da tarefa é obrigatório.", "erro")
        return redirect(url_for("dashboard"))

    conexao = conectar_banco()
    cursor = conexao.cursor()
    cursor.execute(
        "INSERT INTO tarefas (usuario_id, titulo, descricao, status) VALUES (?, ?, ?, ?)",
        (session["usuario_id"], titulo, descricao, "pendente")
    )
    conexao.commit()
    conexao.close()

    flash("Tarefa criada com sucesso!", "sucesso")
    return redirect(url_for("dashboard"))


# ---------------------------------------------------------
# EDITAR TAREFA
# ---------------------------------------------------------

@app.route("/tarefa/<int:tarefa_id>/editar", methods=["GET", "POST"])
@login_obrigatorio
def editar(tarefa_id):
    conexao = conectar_banco()
    cursor = conexao.cursor()

    # Garante que a tarefa pertence ao usuário logado
    cursor.execute(
        "SELECT * FROM tarefas WHERE id = ? AND usuario_id = ?",
        (tarefa_id, session["usuario_id"])
    )
    tarefa = cursor.fetchone()

    if tarefa is None:
        conexao.close()
        flash("Tarefa não encontrada.", "erro")
        return redirect(url_for("dashboard"))

    if request.method == "POST":
        titulo = request.form.get("titulo", "").strip()
        descricao = request.form.get("descricao", "").strip()

        if not titulo:
            flash("O título da tarefa é obrigatório.", "erro")
            conexao.close()
            return redirect(url_for("editar", tarefa_id=tarefa_id))

        cursor.execute(
            "UPDATE tarefas SET titulo = ?, descricao = ? WHERE id = ? AND usuario_id = ?",
            (titulo, descricao, tarefa_id, session["usuario_id"])
        )
        conexao.commit()
        conexao.close()

        flash("Tarefa atualizada com sucesso!", "sucesso")
        return redirect(url_for("dashboard"))

    conexao.close()
    return render_template("editar.html", tarefa=tarefa)


# ---------------------------------------------------------
# EXCLUIR TAREFA
# ---------------------------------------------------------

@app.route("/tarefa/<int:tarefa_id>/excluir", methods=["POST"])
@login_obrigatorio
def excluir(tarefa_id):
    conexao = conectar_banco()
    cursor = conexao.cursor()
    cursor.execute(
        "DELETE FROM tarefas WHERE id = ? AND usuario_id = ?",
        (tarefa_id, session["usuario_id"])
    )
    conexao.commit()
    conexao.close()

    flash("Tarefa excluída com sucesso!", "sucesso")
    return redirect(url_for("dashboard"))


# ---------------------------------------------------------
# CONCLUIR / REABRIR TAREFA
# ---------------------------------------------------------

@app.route("/tarefa/<int:tarefa_id>/concluir", methods=["POST"])
@login_obrigatorio
def concluir(tarefa_id):
    conexao = conectar_banco()
    cursor = conexao.cursor()

    cursor.execute(
        "SELECT status FROM tarefas WHERE id = ? AND usuario_id = ?",
        (tarefa_id, session["usuario_id"])
    )
    tarefa = cursor.fetchone()

    if tarefa is None:
        conexao.close()
        flash("Tarefa não encontrada.", "erro")
        return redirect(url_for("dashboard"))

    # Alterna o status entre pendente e concluída
    novo_status = "concluida" if tarefa["status"] == "pendente" else "pendente"

    cursor.execute(
        "UPDATE tarefas SET status = ? WHERE id = ? AND usuario_id = ?",
        (novo_status, tarefa_id, session["usuario_id"])
    )
    conexao.commit()
    conexao.close()

    if novo_status == "concluida":
        flash("Tarefa marcada como concluída!", "sucesso")
    else:
        flash("Tarefa reaberta.", "sucesso")

    return redirect(url_for("dashboard"))


# ---------------------------------------------------------
# ROTA JSON - LISTAR TAREFAS (usada pela pesquisa/filtro via fetch)
# ---------------------------------------------------------

@app.route("/tarefas")
@login_obrigatorio
def tarefas_json():
    pesquisa = request.args.get("q", "").strip()
    filtro_status = request.args.get("status", "todas")

    conexao = conectar_banco()
    cursor = conexao.cursor()

    consulta = "SELECT * FROM tarefas WHERE usuario_id = ?"
    parametros = [session["usuario_id"]]

    if pesquisa:
        consulta += " AND (titulo LIKE ? OR descricao LIKE ?)"
        termo = f"%{pesquisa}%"
        parametros.append(termo)
        parametros.append(termo)

    if filtro_status in ("pendente", "concluida"):
        consulta += " AND status = ?"
        parametros.append(filtro_status)

    consulta += " ORDER BY data_criacao DESC"

    cursor.execute(consulta, parametros)
    linhas = cursor.fetchall()
    conexao.close()

    tarefas = []
    for linha in linhas:
        tarefas.append({
            "id": linha["id"],
            "titulo": linha["titulo"],
            "descricao": linha["descricao"],
            "status": linha["status"]
        })

    return jsonify(tarefas)


# ---------------------------------------------------------
# ROTA JSON - CONTAGEM PARA O GRÁFICO DE ROSCA
# ---------------------------------------------------------

@app.route("/status_tarefas")
@login_obrigatorio
def status_tarefas():
    conexao = conectar_banco()
    cursor = conexao.cursor()

    cursor.execute(
        "SELECT COUNT(*) AS total FROM tarefas WHERE usuario_id = ? AND status = 'pendente'",
        (session["usuario_id"],)
    )
    pendentes = cursor.fetchone()["total"]

    cursor.execute(
        "SELECT COUNT(*) AS total FROM tarefas WHERE usuario_id = ? AND status = 'concluida'",
        (session["usuario_id"],)
    )
    concluidas = cursor.fetchone()["total"]

    conexao.close()

    return jsonify({"pendentes": pendentes, "concluidas": concluidas})


# ---------------------------------------------------------
# EXECUÇÃO DO PROGRAMA
# ---------------------------------------------------------

if __name__ == "__main__":
    criar_banco()  # cria o banco e as tabelas automaticamente
    app.run(debug=True)
