# Painel de Tarefas

Sistema web para gerenciamento de tarefas pessoais, desenvolvido como atividade da disciplina de Python, do curso Técnico em Informática.

**Autora:** [alice]

## Sobre o projeto

O Painel de Tarefas permite que cada usuário crie sua própria conta, faça login e gerencie suas tarefas de forma individual. Cada usuário só consegue ver e alterar as tarefas que ele mesmo criou.

## Tecnologias utilizadas

- Python 3
- Flask
- SQLite (com o módulo `sqlite3` da biblioteca padrão)
- HTML5 e Bootstrap 5
- Bootstrap Icons
- JavaScript (fetch API)
- Chart.js

## Funcionalidades

- Cadastro de usuários com nome, e-mail e senha
- Login e logout com sessão
- Senhas protegidas com hash (`generate_password_hash` / `check_password_hash`)
- Criação, edição e exclusão de tarefas (com confirmação)
- Concluir e reabrir tarefas
- Pesquisa por título ou descrição sem recarregar a página
- Filtros: todas, pendentes e concluídas
- Gráfico de rosca (Chart.js) com a quantidade de tarefas pendentes e concluídas
- Modo claro e escuro, com a preferência salva no `localStorage`
- Mensagens de sucesso, aviso e erro (`flash`)
- Proteção de rotas: só é possível acessar o painel estando logado
- Banco de dados e tabelas criados automaticamente ao rodar o programa

## Estrutura de pastas

```text
painel-tarefas/
├── app.py
├── requirements.txt
├── README.md
├── .gitignore
├── static/
│   └── js/
│       └── script.js
└── templates/
    ├── cadastro.html
    ├── editar.html
    ├── login.html
    └── painel.html
```

## Como executar o projeto

### 1. Criar e ativar o ambiente virtual (Windows / terminal do VS Code)

```bash
python -m venv .venv
.venv\Scripts\activate
```

### 2. Instalar as dependências

```bash
pip install -r requirements.txt
```

### 3. Executar a aplicação

```bash
python app.py
```

### 4. Acessar no navegador

```text
http://127.0.0.1:5000
```

O arquivo `tarefas.db` e as tabelas do banco são criados automaticamente na primeira execução.

## Banco de dados

O sistema utiliza duas tabelas:

- **usuarios**: id, nome, email, senha (criptografada)
- **tarefas**: id, usuario_id, titulo, descricao, status, data_criacao

Todas as consultas SQL usam parâmetros `?` para evitar SQL Injection.

## Testes sugeridos

1. Cadastrar um novo usuário
2. Fazer login com o usuário cadastrado
3. Tentar acessar `/dashboard` sem estar logado (deve redirecionar para o login)
4. Criar uma nova tarefa
5. Pesquisar uma tarefa pelo título e pela descrição
6. Filtrar por pendentes e por concluídas
7. Editar uma tarefa
8. Concluir e depois reabrir uma tarefa
9. Excluir uma tarefa (confirmando a exclusão)
10. Alternar entre modo claro e escuro e recarregar a página para ver se o tema permaneceu
11. Fazer logout
