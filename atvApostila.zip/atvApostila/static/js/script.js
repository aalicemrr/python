// script.js
// Controla o tema claro/escuro, a pesquisa sem recarregar a página,
// os filtros de status e o gráfico de rosca do painel de tarefas.

document.addEventListener("DOMContentLoaded", function () {

    // -------------------------------------------------
    // MODO CLARO / ESCURO
    // -------------------------------------------------
    const botaoTema = document.getElementById("botao-tema");
    const html = document.documentElement;

    function aplicarTema(tema) {
        html.setAttribute("data-bs-theme", tema);
        if (botaoTema) {
            const icone = botaoTema.querySelector("i");
            if (icone) {
                icone.className = tema === "dark" ? "bi bi-sun" : "bi bi-moon-stars";
            }
        }
    }

    // Recupera o tema salvo no localStorage (padrão: claro)
    const temaSalvo = localStorage.getItem("tema") || "light";
    aplicarTema(temaSalvo);

    if (botaoTema) {
        botaoTema.addEventListener("click", function () {
            const temaAtual = html.getAttribute("data-bs-theme");
            const novoTema = temaAtual === "dark" ? "light" : "dark";
            aplicarTema(novoTema);
            localStorage.setItem("tema", novoTema);
        });
    }

    // -------------------------------------------------
    // PAINEL DE TAREFAS (só executa se os elementos existirem)
    // -------------------------------------------------
    const listaTarefas = document.getElementById("lista-tarefas");
    if (!listaTarefas) {
        return; // não estamos na página do painel
    }

    const campoPesquisa = document.getElementById("campo-pesquisa");
    const botoesFiltro = document.querySelectorAll(".botao-filtro");
    const modeloTarefa = document.getElementById("modelo-tarefa");
    const formConcluir = document.getElementById("form-concluir");
    const formExcluir = document.getElementById("form-excluir");

    let filtroAtual = "todas";
    let temporizadorPesquisa = null;
    let grafico = null;

    // Traduz o status para exibição
    function textoStatus(status) {
        return status === "concluida" ? "Concluída" : "Pendente";
    }

    // Monta um card de tarefa a partir do modelo (template)
    function criarCartaoTarefa(tarefa) {
        const clone = modeloTarefa.content.cloneNode(true);

        clone.querySelector(".titulo-tarefa").textContent = tarefa.titulo;

        const descricao = clone.querySelector(".descricao-tarefa");
        descricao.textContent = tarefa.descricao || "Sem descrição";

        const status = clone.querySelector(".status-tarefa");
        status.textContent = textoStatus(tarefa.status);
        status.classList.add(tarefa.status === "concluida" ? "bg-success" : "bg-warning");

        const cartao = clone.querySelector(".cartao-tarefa");
        if (tarefa.status === "concluida") {
            cartao.classList.add("border-success-subtle");
            cartao.querySelector(".titulo-tarefa").classList.add("text-decoration-line-through");
        }

        // Botão editar leva para a rota de edição
        clone.querySelector(".botao-editar").href = "/tarefa/" + tarefa.id + "/editar";

        // Botão concluir/reabrir envia o formulário oculto
        clone.querySelector(".botao-concluir").addEventListener("click", function () {
            formConcluir.action = "/tarefa/" + tarefa.id + "/concluir";
            formConcluir.submit();
        });

        // Botão excluir pede confirmação antes de enviar
        clone.querySelector(".botao-excluir").addEventListener("click", function () {
            const confirmar = confirm("Tem certeza que deseja excluir a tarefa \"" + tarefa.titulo + "\"?");
            if (confirmar) {
                formExcluir.action = "/tarefa/" + tarefa.id + "/excluir";
                formExcluir.submit();
            }
        });

        return clone;
    }

    // Busca as tarefas no servidor (via fetch) e atualiza a lista na tela
    function carregarTarefas() {
        const termo = campoPesquisa.value.trim();
        const url = "/tarefas?q=" + encodeURIComponent(termo) + "&status=" + encodeURIComponent(filtroAtual);

        fetch(url)
            .then(function (resposta) {
                return resposta.json();
            })
            .then(function (tarefas) {
                listaTarefas.innerHTML = "";

                if (tarefas.length === 0) {
                    listaTarefas.innerHTML = '<p class="text-muted text-center">Nenhuma tarefa encontrada.</p>';
                    return;
                }

                tarefas.forEach(function (tarefa) {
                    listaTarefas.appendChild(criarCartaoTarefa(tarefa));
                });
            })
            .catch(function () {
                listaTarefas.innerHTML = '<p class="text-danger text-center">Erro ao carregar as tarefas.</p>';
            });
    }

    // Busca a contagem de tarefas e desenha o gráfico de rosca
    function carregarGrafico() {
        fetch("/status_tarefas")
            .then(function (resposta) {
                return resposta.json();
            })
            .then(function (dados) {
                const canvas = document.getElementById("grafico-tarefas");
                if (!canvas) return;

                const dadosGrafico = {
                    labels: ["Pendentes", "Concluídas"],
                    datasets: [{
                        data: [dados.pendentes, dados.concluidas],
                        backgroundColor: ["#ffc107", "#198754"]
                    }]
                };

                if (grafico) {
                    grafico.data = dadosGrafico;
                    grafico.update();
                } else {
                    grafico = new Chart(canvas, {
                        type: "doughnut",
                        data: dadosGrafico,
                        options: {
                            responsive: true,
                            plugins: {
                                legend: { position: "bottom" }
                            }
                        }
                    });
                }
            });
    }

    // Atualiza lista e gráfico juntos
    function atualizarPainel() {
        carregarTarefas();
        carregarGrafico();
    }

    // Pesquisa com pequeno atraso (debounce) para não pesquisar a cada tecla
    campoPesquisa.addEventListener("input", function () {
        clearTimeout(temporizadorPesquisa);
        temporizadorPesquisa = setTimeout(carregarTarefas, 300);
    });

    // Filtros de status (Todas / Pendentes / Concluídas)
    botoesFiltro.forEach(function (botao) {
        botao.addEventListener("click", function () {
            botoesFiltro.forEach(function (b) { b.classList.remove("ativo", "btn-primary"); b.classList.add("btn-outline-primary"); });
            botao.classList.add("ativo", "btn-primary");
            botao.classList.remove("btn-outline-primary");

            filtroAtual = botao.getAttribute("data-status");
            carregarTarefas();
        });
    });

    // Carrega tudo assim que a página abre
    atualizarPainel();
});
